﻿
using Infosys.BioKartDAL.Models;
using System;
using System.Collections.Generic;

namespace Infosys.BioKartConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            

        }
    }
}
