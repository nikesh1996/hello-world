﻿using Infosys.BioKartDAL.Models;
using System;
using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.BioKartMVC.Repository
{
    public class BioKartMappers : Profile
    {
        public BioKartMappers()
        {
            CreateMap<FarmerStock, Models.FarmerStock>();
            CreateMap<Models.FarmerStock, FarmerStock>();

            CreateMap<PastAuctionResult, Models.PastAuctionResult>();
            CreateMap<Models.PastAuctionResult, PastAuctionResult>();

            CreateMap<Auctioncart, Models.AuctionCart>();
            CreateMap<Models.AuctionCart, Auctioncart>();

            CreateMap<Auctionstock, Models.Auctionstock>();
            CreateMap<Models.Auctionstock, Auctionstock>();

            CreateMap<PurchaseDetails, Models.PurchaseDetails>();
            CreateMap<Models.PurchaseDetails, PurchaseDetails>();

            CreateMap<Users, Models.FarmerDetails>();
            CreateMap<Models.FarmerDetails, Users>();

            CreateMap<Cart, Models.FarmerStock>();
            CreateMap<Models.FarmerStock, Cart>();

            CreateMap<Users, Models.EmployeeUser>();
            CreateMap<Models.EmployeeUser, Users>();

            CreateMap<Users, Models.FarmerUser>();
            CreateMap<Models.FarmerUser, Users>();
            //__________
            CreateMap<Models.FarmerEmployeeUserD, Users>();
            CreateMap<Users, Models.FarmerEmployeeUserD>();


            CreateMap<Models.CustomerEmployeeUserD, Users>();
            CreateMap<Users, Models.CustomerEmployeeUserD>();

            CreateMap<Cart, Models.Cart>();
            CreateMap<Models.Cart, Cart>();

              CreateMap<Categories, Models.FarmerStock>();
            CreateMap<Models.FarmerStock, Categories>();

            CreateMap<Requests, Models.Request>();
            CreateMap<Models.Request, Requests>();

            CreateMap<AdminForwardedRequest, Models.AdminForwardedRequests>();
            CreateMap<Models.AdminForwardedRequests, AdminForwardedRequest>();

            CreateMap<Notifications, Models.Notifications>();
            CreateMap<Models.Notifications, Notifications>();

            CreateMap<AuctionItem, Models.AuctionItem>();
            CreateMap<Models.AuctionItem, AuctionItem>();

            CreateMap<AuctionBid, Models.AuctionBid>();
            CreateMap<Models.AuctionBid, AuctionBid>();

            CreateMap<Feedback, Models.FeedBack>();
            CreateMap<Models.FeedBack, Feedback>();
        }
    }
}
