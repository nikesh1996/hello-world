﻿using Infosys.BioKartDAL.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Infosys.BioKartDAL
{
    public class BioKartRepository
    {
        private readonly BioKartContext _context;

        public BioKartRepository(BioKartContext context)
        {
            _context = context;
        }



        public string ValidateCredentials(string emailId, string password)
        {
            var user = (from p in _context.Users
                         where p.EmailId == emailId
                         select p).FirstOrDefault();
            string roleId = "invalid";
            if (user.UserPassword == password)
            {
                roleId = user.RoleId;
            }

            return roleId;
        
    }


        public bool CustomerRegister(string userName, string emailId, string password, string birthPlace, long mobileNumber, decimal pinCode, string Address)
        {
            bool status = false;
            try
            {
                Users userObj = new Users();
                userObj.Name = userName;
                userObj.EmailId = emailId;
                userObj.UserPassword = password;
                userObj.Security = birthPlace;
                userObj.PhoneNo = mobileNumber;
                userObj.Pin = pinCode;
                userObj.Address = Address;
                userObj.RoleId = "C";
                userObj.Pan = null;
           
                _context.Users.Add(userObj);
                _context.SaveChanges();
                status= true;
            }
            catch (Exception e)
            {
                status= false;
            }
            return status;
        }


        public bool EmployeeRegister(string userName, string emailId, string password, string birthPlace, long mobileNumber, decimal pinCode, string Address)
        {
            bool status = false;
            try
            {
                Users userObj = new Users();
                userObj.Name = userName;
                userObj.EmailId = emailId;
                userObj.UserPassword = password;
                userObj.Security = birthPlace;
                userObj.PhoneNo = mobileNumber;
                userObj.Pin = pinCode;
                userObj.Address = Address;
                userObj.RoleId = "E";
                userObj.Pan = null;

                _context.Users.Add(userObj);
                _context.SaveChanges();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            return status;
        }



        public bool FarmerRegister(string userName, string emailId, string password, string birthPlace, string pan, long mobileNumber, decimal PinCode, string Address)
        {
            bool status = false;

            try
            {
               
                Users userObj = new Users();
                userObj.Name = userName;
                userObj.EmailId = emailId;
                userObj.UserPassword = password;
                userObj.Security = birthPlace;
                userObj.Pan = pan;
                userObj.PhoneNo = mobileNumber;
                userObj.Pin = PinCode;
                userObj.Address = Address;
                userObj.RoleId = "F";

                _context.Users.Add(userObj);
                _context.SaveChanges();
                status =  true;
            }
            catch (Exception e)
            {
                status =  false;
            }
            return status;
        }


        public bool SecurityCheckPassword(string birthplace, string emailId)
        {
            var user = (from p in _context.Users
                        where p.EmailId == emailId
                        select p).FirstOrDefault();
            if(user.Security==birthplace)
            {
                return true;
            }
            return false;
        }



        public bool ResetPassword(string emailId,string newpass, string confirmpass)
        {
            var user = (from p in _context.Users
                        where p.EmailId == emailId
                        select p).FirstOrDefault();
            if (newpass == confirmpass)
            {
                user.UserPassword = newpass;
                _context.SaveChanges();
                return true;
            }
            else
                return false;
        }
        public bool CollectFeedback(string emailId, string description, long phone)
        {
            bool value = false;
            try
            {
                var user = (from p in _context.Feedback
                            where p.EmailId == emailId
                            select p).FirstOrDefault();
                if (user == null)
                {
                    Feedback obj = new Feedback();

                    obj.EmailId = emailId;
                    obj.Description = description;
                    obj.PhoneNo = phone;
                    _context.Feedback.Add(obj);
                    _context.SaveChanges();
                    value = true;


                }
                else
                {
                    user.Description = description;
                    user.PhoneNo = phone;

                    _context.SaveChanges();
                    value = true;


                }
            }
            catch (Exception et)
            {

                value = false;
            }
            return value;


        }
        public List<Users> GetAllCustomers()
        {
            try
            {
                List<Users> oList = (from p in _context.Users
                            where p.RoleId == "C"
                            select p).ToList();
                return oList;
            }
            catch(Exception e)
            {
                return null;
            }
        }
        public List<Users> GetAllFarmers()
        {
            try
            {
                List<Users> oList = (from p in _context.Users
                                     where p.RoleId == "F"
                                     select p).ToList();
                return oList;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public List<Users> GetAllEmployees()
        {
            try
            {
                List<Users> oList = (from p in _context.Users
                                     where p.RoleId == "E"
                                     select p).ToList();
                return oList;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public List<FarmerStoc> GetWareHouseStock()
        {
            try
            {
                List<FarmerStoc> oList = (from p in _context.FarmerStoc
                                     select p).ToList();
                return oList;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public List<PurchaseDetails> GetMyOrders(string email)
        {
            try
            {
                var query = (from p in _context.Users
                             where p.EmailId == email
                             select p).FirstOrDefault();
                List < PurchaseDetails > oList = (from q in _context.PurchaseDetails
                              where q.Uid == query.Uid
                              select q).ToList();
               
                return oList;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        public Users GetUserDetails(string email)
        {
            try
            {
                var userObj = (from p in _context.Users
                             where p.EmailId == email
                             select p).FirstOrDefault();
               

                return userObj;
            }
            catch (Exception e)
            {
                return null;
            }
        }
        //updateuserdetails
        //servicecart
        //newrequest









    }
}
